import sys
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from PySide6.QtWidgets import QApplication, QMainWindow

from gui import Ui_mainWindow
import src.code.pendulum_calculate as pecal
import src.code.draw as draw


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_mainWindow()
        self.ui.setupUi(self)
        self.ui.pushButton.clicked.connect(self.start_simulation)

    def start_simulation(self):
        data = {
            "system_data": {"g": 9.80665, "dt": 0.0001},
            "pendulum_data": {
                "p1": {
                    "mass": self.ui.p1_mass.value(),
                    "length": self.ui.p1_length.value(),
                    "theta0": self.ui.p1_theta0.value(),
                    "omega0": self.ui.p1_omega0.value(),
                },
                "p2": {
                    "mass": self.ui.p2_mass.value(),
                    "length": self.ui.p2_length.value(),
                    "theta0": self.ui.p2_theta0.value(),
                    "omega0": self.ui.p2_omega0.value(),
                }
            }
        }

        self.Pc = pecal.Pendulum(data)
        self.Dr = draw.PendulumDrawer()

        self.ani = animation.FuncAnimation(
            self.Dr.fig, self.animate, interval=20, blit=True
        )
        plt.show(block=False)

    def animate(self, frame):
        for _ in range(50):
            self.Pc.update()
        return self.Dr.update_positions(self.Pc.p1_pos, self.Pc.p2_pos)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())